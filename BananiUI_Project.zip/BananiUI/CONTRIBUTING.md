# Contributing

1. Fork the repository.
2. Create a separate branch for your change.
3. Keep the source readable and unobfuscated.
4. Do not add analytics, tracking, webhooks, or personal information.
5. Test the minimal and full examples.
6. Explain your changes clearly in the pull request.

Bug reports should include:

- BananiUI version
- Roblox environment
- Error message
- Minimal code that reproduces the issue
