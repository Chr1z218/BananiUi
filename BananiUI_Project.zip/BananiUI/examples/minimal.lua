local BananiUI = loadstring(game:HttpGet(
    "https://raw.githubusercontent.com/YOUR_USERNAME/BananiUI/main/source.lua"
))()

local Window = BananiUI:CreateWindow({
    Name = "My Script",
    LoadingTitle = "My Script",
    LoadingSubtitle = "Powered by BananiUI",
    Theme = "Default",

    ConfigurationSaving = {
        Enabled = true,
        FolderName = "MyScript",
        FileName = "Settings"
    },

    Discord = {
        Enabled = false
    },

    KeySystem = false
})

local Home = Window:CreateTab("Home", 4483362458)

Home:CreateButton({
    Name = "Test Notification",
    Callback = function()
        BananiUI:NotifySuccess("BananiUI is working.")
    end
})

BananiUI:LoadConfiguration()
