local BananiUI = loadstring(game:HttpGet(
    "https://raw.githubusercontent.com/YOUR_USERNAME/BananiUI/main/source.lua"
))()

local Window = BananiUI:CreateWindow({
    Name = "BananiUI Example",
    LoadingTitle = "BananiUI Example",
    LoadingSubtitle = "Public Library Demo",
    Theme = "Default",

    ConfigurationSaving = {
        Enabled = true,
        FolderName = "BananiUIExample",
        FileName = "Settings"
    },

    Discord = {
        Enabled = false
    },

    KeySystem = false
})

local Home = Window:CreateTab("Home", 4483362458)
local Settings = Window:CreateTab("Settings", 4483362458)

Home:CreateSection("Controls")

Home:CreateButton({
    Name = "Success Notification",
    Callback = function()
        BananiUI:NotifySuccess("Everything worked.")
    end
})

Home:CreateButton({
    Name = "Error Notification",
    Callback = function()
        BananiUI:NotifyError("Example error message.")
    end
})

Home:CreateToggle({
    Name = "Example Toggle",
    CurrentValue = false,
    Flag = "ExampleToggle",
    Callback = function(Value)
        print("Toggle:", Value)
    end
})

Home:CreateSlider({
    Name = "Example Slider",
    Range = {0, 100},
    Increment = 1,
    CurrentValue = 50,
    Flag = "ExampleSlider",
    Callback = function(Value)
        print("Slider:", Value)
    end
})

Home:CreateDropdown({
    Name = "Example Dropdown",
    Options = {"One", "Two", "Three"},
    CurrentOption = {"One"},
    Flag = "ExampleDropdown",
    Callback = function(Option)
        print("Dropdown:", Option)
    end
})

Home:CreateInput({
    Name = "Example Input",
    PlaceholderText = "Type here",
    RemoveTextAfterFocusLost = false,
    Callback = function(Text)
        print("Input:", Text)
    end
})

Home:CreateColorPicker({
    Name = "Example Color",
    Color = Color3.fromRGB(255, 221, 0),
    Flag = "ExampleColor",
    Callback = function(Color)
        print("Color:", Color)
    end
})

Settings:CreateKeybind({
    Name = "Example Keybind",
    CurrentKeybind = "K",
    HoldToInteract = false,
    Flag = "ExampleKeybind",
    Callback = function()
        BananiUI:NotifyInfo("Example keybind pressed.")
    end
})

Settings:CreateButton({
    Name = "SafeCall Example",
    Callback = function()
        BananiUI:SafeCall("Example task", function()
            print("SafeCall completed.")
        end)
    end
})

BananiUI:LoadConfiguration()
