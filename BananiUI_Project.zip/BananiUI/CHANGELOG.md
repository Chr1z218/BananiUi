# Changelog

## v1.0.0

- Renamed the public build to BananiUI.
- Removed the startup splash.
- Removed analytics, telemetry, reporter downloads, and heartbeat requests.
- Removed the remote prompt helper.
- Removed the remote Discord boost helper.
- Added success, error, warning, and information notification helpers.
- Added `SafeCall`.
- Added a loaded-script notification with the current game name.
- Added public privacy and attribution documentation.
