# Publishing BananiUI

1. Create a new GitHub repository named `BananiUI`.
2. Upload every file and folder from this project.
3. Copy the exact upstream Rayfield `LICENSE` file into the root.
4. Commit the files.
5. Open `source.lua` and click **Raw**.
6. Use the raw URL in your loader.

Example:

```lua
local BananiUI = loadstring(game:HttpGet(
    "https://raw.githubusercontent.com/YOUR_USERNAME/BananiUI/main/source.lua"
))()
```

Replace `YOUR_USERNAME` with your GitHub username.

Use version tags such as:

- `v1.0.0`
- `v1.1.0`
- `v1.1.1`

Do not place private information or credentials in the repository.
