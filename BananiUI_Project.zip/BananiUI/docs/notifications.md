# Notifications

## Success

```lua
BananiUI:NotifySuccess("Config saved.", "My Script")
```

## Error

```lua
BananiUI:NotifyError("Could not load config.", "My Script")
```

## Warning

```lua
BananiUI:NotifyWarning("Player is unavailable.")
```

## Information

```lua
BananiUI:NotifyInfo("A new update is available.")
```

## SafeCall

```lua
local success, result = BananiUI:SafeCall("Load data", function()
    return loadData()
end)
```
